package com.example.prova;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class activity2 extends activity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Vinculando minha view ao meu controller
        setContentView(R.layout.tela2);

            @Override
            public void onClick(View Object view;
        Object view1 = view;) {
                Intent intent = new Intent(Activity.this, activity2.class);

            }
    }

    private void setContentView(int tela2) {
    }
